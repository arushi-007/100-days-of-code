#include <stdio.h>
int max(int a, int b) { return (a > b) ? a : b; }
int main() {
    int n, i;
    printf("Enter size of array: ");
    scanf("%d", &n);
    int arr[n];
    printf("Enter %d integers:\n", n);
    for(i=0;i<n;i++) scanf("%d",&arr[i]);
    int max_so_far = arr[0], max_ending_here = arr[0];
    for(i=1;i<n;i++) {
        max_ending_here = max(arr[i], max_ending_here + arr[i]);
        max_so_far = max(max_so_far, max_ending_here);
    }
    printf("Maximum sum: %d\n", max_so_far);
    return 0;
}
