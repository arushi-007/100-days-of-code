#include <stdio.h>
#include <string.h>
int main() {
    char s[1001], t[1001];
    printf("Enter two strings: ");
    scanf("%s %s", s, t);
    int count[26] = {0};
    for (int i = 0; s[i]; i++) count[s[i]-'a']++;
    for (int i = 0; t[i]; i++) count[t[i]-'a']--;
    for (int i=0; i<26; i++) if(count[i]!=0) {
        printf("Not Anagram\n");
        return 0;
    }
    printf("Anagram\n");
    return 0;
}
